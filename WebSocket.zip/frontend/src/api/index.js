import request from '../utils/request';

const api = {

    // 用户功能 对应usercontroller
    userLogin(query) {
        return request({
            url: '/user/login',
            method: 'get',
            params: query
        });
    },
    logout(query) {
        return request({
            url: '/user/logout',
            method: 'get',
            params: query
        });
    },
    signIn(data) {
        return request({
            url: '/user/sign-in',
            method: 'post',
            data: data
        });
    },
    getCode(emial) {
        return request({
            url: '/user/getCode',
            method: 'post',
            data: emial
        });
    },
    forgetPassword(form) {
        return request({
            url: '/user/forgetPassword',
            method: 'post',
            data: form
        });
    },
    getUserInfo(query) {
        return request({
            url: '/user/info',
            method: 'get',
            params: query
        });
    },
    getUserInfo2(id) {
        return request({
            url: '/user/info2',
            method: 'get',
            params: { id: id }
        });
    },
    updateUserPublicInfo(data) {
        return request({
            url: '/user/info',
            method: 'post',
            data: data
        });
    },
    updatePassword(query) {
        return request({
            url: '/user/password',
            method: 'get',
            params: query
        });
    },
    

    //私聊功能请求
    getAllConversionList(id) {
        return request({
            url: '/conversionList/listAll',
            method: 'get',
            params: id
        });
    },


    getConversion(data) {
        return request({
            url: '/conversion/allConversion',
            method: 'get',
            params: data
        });
    },

    sendConversion(message) {
        return request({
          url: '/conversion/send',
          method: 'post',
          data: message
        });
    },
    
    getAllConversionListByUserId(id) {
        return request({
            url: '/conversionList/listAll',
            method: 'get',
            params: id
        });
    },
    
    addFriend(data) {
        return request({
            url: '/friend/addFriend',
            method: 'post',
            data: data
        });
    },
    listFriends(amount) {
        return request({
            url: `/friend/listFriends/${amount}`,
            method: 'get'
        });
    }
};


export default api;