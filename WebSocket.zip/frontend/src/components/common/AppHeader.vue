<template>
    <div>
      <div class="header">
        <div class="header-container">
          <div class="app-name">
            <router-link to="/">聊天系统</router-link>
          </div>
          <div class="button-container">
            <el-button type="primary" icon="el-icon-plus" @click="openAddFriendDialog">添加好友</el-button>
            <el-button type="primary" icon="el-icon-chat-dot-round" @click="openFriendListDialog">好友列表</el-button>
          </div>
          <div class="user-container">
            <router-link v-if="!isLogin" class="user-name-text" to="/login">登录</router-link>
            <el-dropdown trigger="click" v-else>
              <div style="cursor:pointer;display: flex;align-items: center;">
                <div style="font-size: 16px;color: #409EFF;padding-right: 5px;">{{nicknameValue ? nicknameValue : nickname}}</div>
                <el-avatar :src="avatarValue ? avatarValue : avatar"></el-avatar>
              </div>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item>
                  <div @click="toMe">个人中心</div>
                </el-dropdown-item>
                <el-dropdown-item divided style="color: red;">
                  <div @click="loginOut">退出登录</div>
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </div>
        </div>
      </div>
  
      <el-dialog title="添加好友" :visible.sync="addFriendDialogVisible" @close="resetAddFriendDialog">
        <el-input v-model="friendUsername" placeholder="请输入好友账号"></el-input>
        <span slot="footer" class="dialog-footer">
          <el-button @click="cancelAddFriend">取消</el-button>
          <el-button type="primary" @click="addFriend">添加好友</el-button>
        </span>
      </el-dialog>
  
      <el-dialog title="好友列表" :visible.sync="friendListDialogVisible" @close="resetFriendListDialog">
        <div v-for="friend in friendList" @click="toConversion(friend.id)" :key="friend.id" class="friend-item">
          <el-avatar :src="friend.avatar" :size="40"></el-avatar>
          <div class="friend-info">
            <div class="friend-nickname">{{ friend.nickname }}</div>
            <!-- 其他好友信息 -->
          </div>
        </div>
      </el-dialog>
    </div>
  </template>
  
  <script>
  import { Dialog, Input } from 'element-ui';
  
  export default {
    name: 'Header',
    components: {
      'el-dialog': Dialog,
      'el-input': Input
    },
    data() {
      return {
        amount: '',
        nickname: '登录',
        avatar: 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png',
        isLogin: false,
        friendList: [{
          id:'',
          nickname: '',
          avatar: ''
        }],             // 好友列表数据
        friendUsername: '',         // 添加好友的输入账号
        addFriendDialogVisible: false,     // 控制添加好友弹窗的显示与隐藏
        friendListDialogVisible: false     // 控制好友列表弹窗的显示与隐藏
      };
    },
    created() {
      // 获取好友列表数据（示例数据，实际需要根据接口获取）
      // this.friendList = [
      //   {
      //     id: 1,
      //     nickname: '好友1',
      //     avatar: 'https://example.com/avatar1.png'
      //   },
      //   {
      //     id: 2,
      //     nickname: '好友2',
      //     avatar: 'https://example.com/avatar2.png'
      //   },
      //   // 其他好友数据
      // ];
      this.$api.getUserInfo().then(res => {
          console.log('Header getUserInfo:', res);
          if (res.status_code === 1) {
            this.amount = res.data.accountNumber;
          }
        });
  
      // 检查登录状态，获取用户信息（示例数据，实际需要根据接口获取）
      if (!this.$globalData.userInfo.nickname) {
        this.$api.getUserInfo().then(res => {
          console.log('Header getUserInfo:', res);
          if (res.status_code === 1) {
            this.nickname = res.data.nickname;
            this.avatar = res.data.avatar;
            this.amount = res.data.accountNumber;
            console.log('this.amount:', this.amount);
            res.data.signInTime = res.data.signInTime.substring(0, 10);
            this.$globalData.userInfo = res.data;
            this.isLogin = true;
          }
        });
      } else {
        this.nickname = this.$globalData.userInfo.nickname;
        this.avatar = this.$globalData.userInfo.avatar;
        this.isLogin = true;
      }
    },
    methods: {
      toMe() {
        if ('/me' !== this.$route.path) {
          this.$router.push({ path: '/me' });
        }
      },
      toConversion(id) {
        this.$router.push('/conversion?toId=' + id);
      },
  
      loginOut() {
        this.$api.logout().then(res => {
          if (res.status_code === 1) {
            this.$globalData.userInfo = {};
            console.log('login out');
            if ('/index' === this.$route.path) {
              this.$router.go(0);
            } else {
              this.$router.push({ path: '/index' });
            }
          } else {
            this.$message.error('网络或系统异常，退出登录失败！');
          }
        });
      },
  
      openAddFriendDialog() {
        this.addFriendDialogVisible = true;
      },
  
      resetAddFriendDialog() {
        this.friendUsername = '';
      },
  
      cancelAddFriend() {
        this.addFriendDialogVisible = false;
      },
  
      addFriend() {
        const requestData = {
          amount: this.amount,
          friendUsername: this.friendUsername
        };

        // 处理添加好友逻辑，根据friendUsername发起请求等
        this.$api.addFriend({amount: this.amount,friendUsername: this.friendUsername}).then(res => {
          if (res.status_code === 1) {
            
          } else {
            this.$message.error('网络或系统异常，添加失败！');
          }
        });
        // 示例代码
        console.log('添加好友:', this.friendUsername);
        // 清空输入框
        this.friendUsername = '';
        // 关闭弹窗
        this.addFriendDialogVisible = false;
      },
  
      openFriendListDialog() {
        this.$api.listFriends(this.amount).then(res => {
          if (res.status_code === 1) {
            this.friendList = res.data;
          }
          console.log('---------------', this.friendList)
        });
        this.friendListDialogVisible = true;
      },
  
      resetFriendListDialog() {
        // 重置好友列表数据
        //this.friendList = [];
      }
    }
  };
  </script>
  
  <style scoped>
  .header {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    width: 100%;
    height: 58px;
    background: #ffffff;
    display: flex;
    justify-content: center;
    border-bottom: #eeeeee solid 2px;
    z-index: 1000;
  }
  
  .header-container {
    width: 1000px;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  
  .app-name a {
    color: #409EFF;
    font-size: 24px;
    text-decoration: none;
  }
  
  .user-container {
    display: flex;
    align-items: center;
  }
  
  .user-container .user-name-text {
    font-size: 16px;
    font-weight: 600;
    color: #409EFF;
    cursor: pointer;
    text-decoration: none;
  }
  
  .user-container .el-button {
    margin-left: 10px;
  }

  .friend-item {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.friend-item .friend-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
}

.friend-item .friend-info {
  display: flex;
  align-items: center;
  margin-left: 10px;
}

.friend-item .friend-nickname {
  font-size: 16px;
  font-weight: 600;
  color: #333;
}
  </style>
  