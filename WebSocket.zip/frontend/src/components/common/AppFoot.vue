<template>
    <div class="foot-container">
        <div class="author">欢迎使用聊天系统</div>
    </div>
</template>

<script>
    export default {
        name: "Foot"
    }
</script>

<style scoped>
    .foot-container {
        width: 100%;
        display: flex;
        justify-content: center;
        height: 40px;
        padding-top: 10px;
    }

    .author {
        color: #999999;
        font-size: 14px;
    }
</style>