<template>
  <div class="forgot-password-container">
    <el-card class="box-card">
      <div class="forgot-password-body">
        <div class="forgot-password-title">找回密码</div>
        <el-form ref="form" :model="form">
          <el-form-item label="注册邮箱" prop="email">
            <el-input v-model="form.email" placeholder="请输入邮箱地址"></el-input>
          </el-form-item>
          <el-form-item label="验证码" prop="code">
            <el-row gutter="10">
              <el-col :span="16">
                <el-input v-model="form.code" placeholder="请输入验证码"></el-input>
              </el-col>
              <el-col :span="8">
                <el-button type="primary" @click="sendCode" :disabled="disableSendCode">{{ sendText }}</el-button>
              </el-col>
            </el-row>
          </el-form-item>
          <el-form-item label="新密码" prop="password">
            <el-input v-model="form.password" type="password" placeholder="请输入新密码"></el-input>
          </el-form-item>
          <el-form-item label="确认密码" prop="confirmPassword">
            <el-input v-model="confirmPassword" type="password" placeholder="请再次输入新密码"></el-input>
          </el-form-item>
          <div class="forgot-password-submit">
            <el-button type="primary" @click="submitForm">提交</el-button>
          </div>
        </el-form>
      </div>
    </el-card>
  </div>
</template>
<script>
export default {
  data() {
    return {
      form: {
        email: '',
        code: '',
        password: '',
      },
      confirmPassword: '',
      sendText: '发送验证码',
      disableSendCode: false,
    };
  },
  methods: {
    sendCode() {
      if (this.checkEmail() == false) {
        return false;
      } else {
        this.$api.getCode(encodeURIComponent(this.form.email)).then(res => {
          if (res.status_code === 1) {
            this.$message({
              message: '验证码发送成功！',
              type: 'success'
            });
          } else {
            this.$message.error('发送失败，请重试！');
          }
        });
        
        this.disableSendCode = true;
        let seconds = 60;
        const timer = setInterval(() => {
          seconds--;
          if (seconds <= 0) {
            clearInterval(timer);
            this.disableSendCode = false;
            this.sendText = '重新发送';
          } else {
            this.sendText = `${seconds}s后重新发送`;
          }
        }, 1000);
      }
    },
    checkEmail() {
      let email = this.form.email;
      if (!/^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/.test(email)) {
        this.$message.error("请填写正确的邮箱号");
          return false;
      }
    },
    toLogin(){
      this.$router.replace({path: '/login'});
    },
    submitForm() {
      // TODO: 提交表单的逻辑
      if(this.confirmPassword !== this.form.password) {
        this.$message.error('两次输入的密码不相同！');
      } else {
        this.$api.forgetPassword(this.form).then(res => {
          if (res.status_code === 1) {
            this.$message({
              message: '找回密码！',
              type: 'success'
            });
            this.toLogin();
          } else {
            this.$message.error('请重试！');
          }
        });
      }
    }
  },
};
</script>
<style scoped>
  .forgot-password-container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
  }
  .forgot-password-body {
    max-width: 500px;
    margin: 0 auto;
  }
  .forgot-password-title {
    font-size: 20px;
    text-align: center;
    margin-bottom: 20px;
  }
  .forgot-password-submit {
    text-align: center;
    margin-top: 30px;
  }
</style>