<template>
  <div>
    <app-head :nickname-value="userInfo.nickname" :avatarValue="userInfo.avatar"></app-head>
    <app-body>
      <div class="chat-container">
        <ul class="message-list">
          <li v-for="message in messages" :key="message.id" :class="{'message-item': true, 'sender': message.senderId === userInfo.id, 'receiver': message.senderId !== userInfo.id}">
            <div class="message-content">
              <div v-if="message.senderId !== userInfo.id" class="receiver-message">
                <div class="message-info">
                  <img :src="userInfo2.avatar" class="avatar" alt="头像">
                  <div class="message-bubble">{{ message.message }}</div>
                </div>
                <div class="timestamp">{{ message.time }}</div>
              </div>
              <div v-else class="sender-message">
                <div class="message-info">
                  <div class="message-bubble">{{ message.message }}</div>
                  <img :src="userInfo.avatar" class="avatar" alt="头像">
                </div>
                <div class="timestamp">{{ message.time }}</div>
              </div>
            </div>
          </li>
        </ul>
        <div class="message-input">
          <input type="text" v-model="newMessage" placeholder="输入消息...">
          <button @click="sendMessage">发送</button>
        </div>
      </div>
      <app-foot></app-foot>
    </app-body>
  </div>
</template>

<script>
import AppHead from '../common/AppHeader.vue';
import AppBody from '../common/AppPageBody.vue';
import AppFoot from '../common/AppFoot.vue';

export default {
  name: "conversion",
  components: {
    AppHead,
    AppBody,
    AppFoot
  },
  data() {
    return {
      userInfo: {
        id: "",
        accountNumber: "",
        avatar: "",
        nickname: "",
        signInTime: "",
      },
      userInfo2: {
        avatar: "",
        nickname: "",
        signInTime: "",
        id: ""
      },
      messageInfo: {
        message: "",
        time: "",
        senderId: "",
        receiverId: "",
      },
      messages: [
        {
          senderId: "",
          receiverId: "",
          message: "",
          time: ""
        }
      ],
      newMessage: ''
    };
  },
  async created() {
    try {
      const userInfoResponse = await this.$api.getUserInfo();
      if (userInfoResponse.status_code === 1) {
        userInfoResponse.data.signInTime = userInfoResponse.data.signInTime.substring(0, 10);
        this.userInfo.id = userInfoResponse.data.id;
        this.$globalData.userInfo = userInfoResponse.data;
        this.userInfo = this.$globalData.userInfo;
        this.userInfo2.id = this.$route.query.toId;
      }
    } catch (error) {
      // 处理错误
    }

    try {
      const userInfo2Response = await this.$api.getUserInfo2(this.$route.query.toId);
      if (userInfo2Response.status_code === 1) {
        this.userInfo2 = userInfo2Response.data;
      }
    } catch (error) {
      // 处理错误
    }

    try {
      const conversionResponse = await this.$api.getConversion({ id1: this.userInfo.id, id2: this.$route.query.toId });
      if (conversionResponse.status_code === 1) {
        this.messages = conversionResponse.data;
      }
    } catch (error) {
      // 处理错误
    }

    // 在此之后执行其他操作
    // 建立 WebSocket 连接
    this.websocket = new WebSocket('ws://localhost:8089/conversion/send');

    // 监听消息事件
    this.websocket.onmessage = (event) => {
      const message = JSON.parse(event.data);
      this.handleReceivedMessage(message);
    };
  },

  methods: {
    handleReceivedMessage(message) {
      // 判断接收到的消息是否为当前聊天对象的消息
      const isCurrentConversation =
        (message.senderId === this.userInfo.id && message.receiverId === this.userInfo2.id) ||
        (message.senderId === this.userInfo2.id && message.receiverId === this.userInfo.id);

      if (isCurrentConversation) {
        // 在接收者界面显示消息
        this.messages.push(message);
      }
    },
    sendMessage() {
      if (this.newMessage !== '') {
        const date = new Date();
        this.messageInfo.message = this.newMessage;
        this.messageInfo.time = date.toLocaleString('zh-cn');
        this.messageInfo.senderId = this.userInfo.id;
        this.messageInfo.receiverId = this.userInfo2.id;

        // 将消息转换为 JSON 字符串
        const messageJson = JSON.stringify(this.messageInfo);

        // 将消息发送给后端
        this.websocket.send(messageJson);

        // 在发送者界面显示消息
        const sentMessage = {
          senderId: this.messageInfo.senderId,
          receiverId: this.messageInfo.receiverId,
          message: this.messageInfo.message,
          time: this.messageInfo.time
        };
        this.messages.push(sentMessage);

        this.newMessage = '';
      }
    },
  }
};
</script>

<style scoped>
.message-list {
  list-style-type: none;
  padding: 0;
}

.message-content {
  display: flex;
  align-items: center;
  margin-bottom: 5px;
}

.receiver-message {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  margin-right: auto;
}

.sender-message {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  margin-left: auto;
}

.avatar {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  margin-right: 10px;
}

.message-input {
  display: flex;
  margin-top: 10px;
}

.message-input input[type="text"] {
  flex-grow: 1;
  padding: 5px;
  border: none;
  border-radius: 3px;
}

.message-input button {
  margin-left: 10px;
  padding: 5px 10px;
  border: none;
  border-radius: 3px;
  background-color: #4CAF50;
  color: white;
  cursor: pointer;
}

.timestamp {
  font-size: 12px;
  color: #777;
}

.message-info {
  display: flex;
  align-items: center;
  margin-bottom: 5px;
}

.message-bubble {
  background-color: #e1f2fb;
  padding: 5px;
  border-radius: 5px;
  max-width: 200px;
  word-break: break-word;
  line-height: 1.4;
  margin-bottom: 2px;
}
</style>