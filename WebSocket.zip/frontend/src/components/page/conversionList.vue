<template>
  <div>
    <app-head :nickname-value="userInfo.nickname" :avatarValue="userInfo.avatar"></app-head>
    <app-body>
      <div class="message-list">
        <div v-for="message in messageListInfo" :key="message.id" class="message-item" :class="{'unread': !message.read}"
        @click="goToConversion(message.senderId)">
          <div class="avatar-wrapper">
            <img :src="message.avatar" class="avatar" alt="头像">
          </div>
          <div class="message-details">
            <div class="message-info">
              <div class="message-sender">{{ message.sender }}</div>
              <div class="message-timestamp">{{ message.lastTime }}</div>
            </div>
            <div class="message-content">
              <div class="message-preview">{{ message.message }}</div>
              <div v-if="message.unreadCount > 0" class="unread-count">{{ message.unreadCount }}</div>
            </div>
          </div>
        </div>
      </div>
      <app-foot></app-foot>
    </app-body>
  </div>
</template>

<script>
import AppHead from '../common/AppHeader.vue';
import AppBody from '../common/AppPageBody.vue';
import AppFoot from '../common/AppFoot.vue';

export default {
  name: "conversion",
  components: {
    AppHead,
    AppBody,
    AppFoot
  },
  data() {
    return {
      messageListInfo: [
          {
            senderId: "",
            sender: "",
            avatar: "",
            message:"",
            lastTime: "",
            unreadCount: ""
          }
      ],
      userInfo: {
        accountNumber: "",
        avatar: "",
        nickname: "",
        signInTime: "",
        id: ""
      },
    
        // Add more messages here

    };
  },
  
  created() {
    if (!this.$globalData.userInfo.nickname) {
      this.$api.getUserInfo().then(res => {
        if (res.status_code === 1) {
          res.data.signInTime = res.data.signInTime.substring(0, 10);
          console.log(res.data);
          this.$globalData.userInfo = res.data;
          this.userInfo = this.$globalData.userInfo;
        }
      });
    } else {
      this.userInfo = this.$globalData.userInfo;
      console.log(this.userInfo);
    }

    this.getAllConversionListByUserId();
  },
  methods: {
    goToConversion(id) {
      // 使用 Vue Router 的编程式导航进行页面跳转
      this.$router.push('/conversion?toId=' + id);
    },
    getAllConversionListByUserId() {
      this.$api.getAllConversionListByUserId({userId : this.userInfo.id}).then(res => {
        if(res.status_code === 1) {
          this.messageListInfo = res.data;
          console.log(this.messageListInfo[0].message + "--------------");

          // 将数据保存到本地存储中
          localStorage.setItem('messageListInfo', JSON.stringify(this.messageListInfo));
        }
      })
    }
  }
};
</script>

  
  <style scoped>
  .message-list {
    padding: 10px;
  }
  
  .message-item {
    display: flex;
    align-items: center;
    padding: 10px;
    border-bottom: 1px solid #ccc;
    cursor: pointer;
    transition: background-color 0.3s;
  }
  
  .message-item:hover {
    background-color: #f0f0f0;
  }
  
  .unread {
    font-weight: bold;
  }
  
  .avatar-wrapper {
    margin-right: 10px;
  }
  
  .avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
  }
  
  .message-details {
    flex-grow: 1;
  }
  
  .message-info {
    display: flex;
    justify-content: space-between;
    margin-bottom: 5px;
  }
  
  .message-sender {
    font-weight: bold;
  }
  
  .message-timestamp {
    color: #888888;
    font-size: 12px;
  }
  
  .message-content {
    display: flex;
    align-items: center;
  }
  
  .message-preview {
    color: #888888;
    font-size: 14px;
    flex-grow: 1;
  }
  
  .unread-count {
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 20px;
    height: 20px;
    background-color: #FF0000;
    color: #FFFFFF;
    font-size: 12px;
    border-radius: 10px;
  }
  </style>
  