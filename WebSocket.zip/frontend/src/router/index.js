import Vue from 'vue';
import Router from 'vue-router';

const originalReplace = Router.prototype.replace;
Router.prototype.replace = function replace(location) {
    return originalReplace.call(this, location).catch(err => err);
};
const originalPush = Router.prototype.push
Router.prototype.push = function push(location) {
    return originalPush.call(this, location).catch(err => err)
};

Vue.use(Router);

export default new Router({
    routes: [
        {
            path: '/',
            redirect: '/conversionList'
        },
        {
            path: '/conversionList',
            /*组件懒加载*/
            component: () => import('../components/page/conversionList.vue'),
            meta: { title: 'talkBox' }
        },
        {
            path: '/me',
            component: () => import('../components/page/me.vue'),
            meta: { title: '个人中心' }
        },
        {
            path: '/login',
            component: () => import('../components/page/login.vue'),
            meta: { title: '登录 | 聊天系统' }
        },
        {
            path: '/sign-in',
            component: () => import('../components/page/sign-in.vue'),
            meta: { title: '注册 | 聊天系统' }
        },
        {
            path: '/login-admin',
            component: () => import('../components/page/login-admin.vue'),
            meta: { title: '管理员登陆' }
        },
        {
            path: '/forgetPassword',
            component: () => import('../components/page/forgetPassword.vue'),
            meta: { title: '忘记密码' }
        },
        {
            path: '/platform-admin',
            component: () => import('../components/page/platform-admin.vue'),
            meta: { title: '后台管理' }
        },
        {
            path: '/conversion',
            component: () => import('../components/page/conversion.vue'),
            meta: { title: '聊天室' }
        },
        {
            path: '/conversionList',
            component: () => import('../components/page/conversionList.vue'),
            meta: { title: '聊天列表' }
        },
        {
            path: '*',
            redirect: '/'
        }
    ]
});
