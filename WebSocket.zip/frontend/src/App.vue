<template>
    <div id="app">
        <router-view></router-view>
    </div>
</template>
<style>
    html, body, #app{
        overflow: visible;
        background-color: #f6f6f6;
    }
</style>