package com.talkBox.server.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.talkBox.server.model.ConversionModel;
import com.talkBox.server.service.ConversionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

@Slf4j
@Component
@ServerEndpoint("/conversion/send")
public class WebSocketConversionHandler extends TextWebSocketHandler {

    private static Set<WebSocketSession> sessions = new HashSet<>();

    @Autowired
    private ConversionService conversionService;

    private static final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        sessions.add(session);
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        log.info("接收到消息: {}", message.getPayload());

        try {
            // 将接收到的消息解析为 ConversionModel 对象
            ConversionModel conversionModel = objectMapper.readValue(message.getPayload(), ConversionModel.class);
            conversionService.addConversion(conversionModel);

            // 处理接收到的消息，例如转发给其他会话
            for (WebSocketSession s : sessions) {
                if (!s.equals(session)) {
                    try {
                        s.sendMessage(message);
                    } catch (IOException e) {
                        log.error("发送消息失败", e);
                    }
                }
            }
        } catch (JsonProcessingException e) {
            log.error("解析消息失败", e);
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        sessions.remove(session);
    }
}