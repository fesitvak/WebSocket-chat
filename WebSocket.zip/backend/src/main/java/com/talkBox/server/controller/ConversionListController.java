package com.talkBox.server.controller;

import com.talkBox.server.model.ConversionListModel;
import com.talkBox.server.model.UserModel;
import com.talkBox.server.service.ConversionListService;
import com.talkBox.server.service.UserService;
import com.talkBox.server.vo.ConversionListVo;
import com.talkBox.server.vo.ResultVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@Slf4j
@RequestMapping("/conversionList")
public class ConversionListController {
    @Autowired
    private ConversionListService conversionListService;

    @Autowired
    private UserService userService;

    @GetMapping("listAll")
    public ResultVo getAllConversionList(@RequestParam Long userId) {
        log.info("调用getAllConversionList请求");
        List<ConversionListModel> conversionList = conversionListService.getConversionListByUserId(userId);

        List<ConversionListVo> conversionListVos = new ArrayList<>();
        for(ConversionListModel conList : conversionList) {
            ConversionListVo conversionListVo = new ConversionListVo();
            conversionListVo.setLastTime(conList.getLastTime());
            conversionListVo.setMessage(conList.getLastMessage());
            Long receiverId = conList.getReceiverId();
            Long sendId = conList.getSendId();
            Long id = userId == sendId ? receiverId : sendId;
            UserModel user = userService.getUser(id);
            String nickname = user.getNickname();
            String avatar = user.getAvatar();
            conversionListVo.setSenderId(id);
            conversionListVo.setAvatar(avatar);
            conversionListVo.setSender(nickname);
            conversionListVo.setUnreadCount(0);
            conversionListVos.add(conversionListVo);
        }
        return ResultVo.success(conversionListVos);
    }

    @GetMapping("update")
    public ResultVo updateConversionList() {
        return null;
    }
}
