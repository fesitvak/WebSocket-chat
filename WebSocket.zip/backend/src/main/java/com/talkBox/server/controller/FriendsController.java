package com.talkBox.server.controller;

import com.talkBox.server.model.UserModel;
import com.talkBox.server.service.FriendsService;
import com.talkBox.server.vo.AddFriendRequest;
import com.talkBox.server.vo.ResultVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/friend")
public class FriendsController {
    @Autowired
    private FriendsService friendsService;

    @PostMapping("/addFriend")
    public ResultVo addFriend(@RequestBody AddFriendRequest request) {
        String amount = request.getAmount();
        String friendUsername = request.getFriendUsername();
        friendsService.addFriend(amount, friendUsername);
        return ResultVo.success();
    }


    @GetMapping("/listFriends/{userAmount}")
    public ResultVo listFriends(@PathVariable String userAmount) {
        List<UserModel> userModelList = friendsService.listFriends(userAmount);
        for (UserModel userModel : userModelList) {
            System.out.println(userModel);
        }
        return ResultVo.success(userModelList);
    }
}
