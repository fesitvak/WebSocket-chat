package com.talkBox.server.vo;

import java.io.Serializable;

/**
 * sh_user
 * @author myl
 */
public class UserModelVo implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 账号（手机号）
     */
    private String accountNumber;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 登录密码
     */
    private String userPassword;

    /**
     * 昵称
     */
    private String nickname;

    /**
     * 头像
     */

    private String code;

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String toString() {
        return "UserModelVo{" +
                "accountNumber='" + accountNumber + '\'' +
                ", email='" + email + '\'' +
                ", userPassword='" + userPassword + '\'' +
                ", nickname='" + nickname + '\'' +
                ", code='" + code + '\'' +
                '}';
    }
}