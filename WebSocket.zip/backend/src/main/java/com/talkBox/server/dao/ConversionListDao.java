package com.talkBox.server.dao;

import com.talkBox.server.model.ConversionListModel;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ConversionListDao {
    int insert(ConversionListModel conversionListModel);
    int update(ConversionListModel conversionListModel);

    List<ConversionListModel> selectByUserId(Long id);

    ConversionListModel selectByABId(Long id1, Long id2);
}
