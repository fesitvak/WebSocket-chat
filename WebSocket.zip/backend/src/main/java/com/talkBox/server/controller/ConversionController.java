package com.talkBox.server.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.talkBox.server.service.ConversionService;
import com.talkBox.server.vo.ResultVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.websocket.Session;
import java.util.HashSet;
import java.util.Set;

@Slf4j
@RestController
@RequestMapping("/conversion")
public class ConversionController {

    @Autowired
    private ConversionService conversionService;

    // 添加 WebSocket 处理器
    private static Set<Session> sessions = new HashSet<>();

    @Autowired
    private ObjectMapper objectMapper;

//    @PostMapping("send")
//    public ResultVo send(@RequestBody ConversionModel conversionModel) {
//        log.info("调用接口send");
//        log.info("send=======================");
//        conversionService.addConversion(conversionModel);
//
//        // 将 ConversionModel 对象转换为 JSON 字符串
//        String jsonMessage;
//        try {
//            jsonMessage = objectMapper.writeValueAsString(conversionModel);
//        } catch (JsonProcessingException e) {
//            log.error("转换消息为 JSON 字符串时出错", e);
//            return ResultVo.fail(ErrorMsg.valueOf("发送消息失败"));
//        }
//
//        // 向所有连接的会话发送消息
//        for (Session session : sessions) {
//            try {
//                session.getBasicRemote().sendText(jsonMessage);
//            } catch (IOException e) {
//                log.error("发送消息失败", e);
//            }
//        }
//
//        return ResultVo.success();
//    }

    @GetMapping("allConversion")
    public ResultVo getAllConversion(@RequestParam("id1") String id1, @RequestParam("id2") String id2) {
        System.out.println(id1 + "-----------------" + id2);
        return ResultVo.success(conversionService.getConversionByABId(Long.valueOf(id1), Long.valueOf(id2)));
    }
}
