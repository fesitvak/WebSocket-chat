package com.talkBox.server.service;

import com.talkBox.server.model.ConversionListModel;

import java.util.List;

public interface ConversionListService {
    int addConversionList(ConversionListModel conversionListModel);

    int updateConversionList(ConversionListModel conversionListModel);

    /**
     * 找与之间相关的
     * @param id
     * @return
     */
    List<ConversionListModel> getConversionListByUserId(Long id);

    /**
     * 找id1， id2相关的
     * @param id1
     * @param id2
     * @return
     */
    ConversionListModel getConversionByABId(Long id1, Long id2);
}
