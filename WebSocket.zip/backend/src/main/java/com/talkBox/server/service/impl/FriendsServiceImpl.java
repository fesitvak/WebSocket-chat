package com.talkBox.server.service.impl;

import com.talkBox.server.dao.FriendsDao;
import com.talkBox.server.dao.UserDao;
import com.talkBox.server.model.FriendsModel;
import com.talkBox.server.model.UserModel;
import com.talkBox.server.service.FriendsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class FriendsServiceImpl implements FriendsService {

    @Autowired
    private FriendsDao friendsDao;

    @Autowired
    private UserDao userDao;

    @Override
    public int addFriend(String userA, String userB) {
        return friendsDao.addFriend(userA, userB);
    }

    @Override
    public List<UserModel> listFriends(String userAmount) {
        List<FriendsModel> friendsModels = friendsDao.listFriends(userAmount);
        List<UserModel> userList = new ArrayList<>();
        for (FriendsModel friend : friendsModels) {
            String userA = friend.getUserA();
            String userB = friend.getUserB();
            String uAmount = userAmount.equals(userA) ? userB : userA;
            UserModel user = userDao.getUserByAmount(uAmount);
            userList.add(user);
        }
        return userList;
    }
}
