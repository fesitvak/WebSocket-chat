package com.talkBox.server.dao;

import com.talkBox.server.model.FriendsModel;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface FriendsDao {
    //添加好友
    @Insert("INSERT INTO sh_friends (userA, userB) VALUES (#{userA}, #{userB})")
    public int addFriend(String userA, String userB);
    //好友列表

    @Select("SELECT * FROM sh_friends WHERE userA = #{userAmount} or userB = #{userAmount}")
    public List<FriendsModel> listFriends(String userAmount);
}
