package com.talkBox.server.service;

import com.talkBox.server.model.ConversionModel;

import java.util.List;

public interface ConversionService {
    public int addConversion(ConversionModel conversionModel);

    public List<ConversionModel> getConversionByABId(Long id1, Long id2);
}
