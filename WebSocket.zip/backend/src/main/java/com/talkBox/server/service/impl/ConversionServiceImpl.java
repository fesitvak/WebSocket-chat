package com.talkBox.server.service.impl;

import com.talkBox.server.dao.ConversionDao;
import com.talkBox.server.model.ConversionListModel;
import com.talkBox.server.model.ConversionModel;
import com.talkBox.server.service.ConversionListService;
import com.talkBox.server.service.ConversionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class ConversionServiceImpl implements ConversionService {
    @Autowired
    private ConversionListService conversionListService;

    @Autowired
    private ConversionDao conversionDao;

    @Override
    public int addConversion(ConversionModel conversionModel) {
        Long id1 = conversionModel.getSenderId();
        Long id2 = conversionModel.getReceiverId();
        ConversionListModel list = conversionListService.getConversionByABId(id1, id2);
        if(list == null) {
            ConversionListModel conversionList = new ConversionListModel();
            conversionList.setLastMessage(conversionModel.getMessage());
            conversionList.setLastTime(new Date());
            conversionList.setSenderId(id1);
            conversionList.setReceiverId(id2);
            conversionListService.addConversionList(conversionList);
        } else {
            list.setLastMessage(conversionModel.getMessage());
            list.setLastTime(conversionModel.getTime());
            conversionListService.updateConversionList(list);
        }
        return conversionDao.insert(conversionModel);
    }

    public List<ConversionModel> getConversionByABId(Long id1, Long id2) {
        return conversionDao.selectByUserId(id1, id2);
    }
}
