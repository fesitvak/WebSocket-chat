package com.talkBox.server.service.impl;

import com.talkBox.server.dao.ConversionListDao;
import com.talkBox.server.model.ConversionListModel;
import com.talkBox.server.service.ConversionListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class ConversionListServiceImpl implements ConversionListService {
    @Autowired
    private ConversionListDao conversionListDao;
    @Override
    public int addConversionList(ConversionListModel conversionListModel) {
        return conversionListDao.insert(conversionListModel);
    }

    @Override
    public int updateConversionList(ConversionListModel conversionListModel) {
        return conversionListDao.update(conversionListModel);
    }

    @Override
    public List<ConversionListModel> getConversionListByUserId(Long id) {
        return conversionListDao.selectByUserId(id);
    }

    @Override
    public ConversionListModel getConversionByABId(Long id1, Long id2) {
        return conversionListDao.selectByABId(id1, id2);
    }
}
