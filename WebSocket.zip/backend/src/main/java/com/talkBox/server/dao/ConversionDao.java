package com.talkBox.server.dao;

import com.talkBox.server.model.ConversionModel;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ConversionDao {
    int insert(ConversionModel conversionModel);
    int update(Long id);

    /**
     * 根据listID查询
     * @param id1, id2
     * @return
     */
    List<ConversionModel> selectByUserId(Long id1, Long id2);
}
