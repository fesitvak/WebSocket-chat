package com.talkBox.server.service;

import com.talkBox.server.model.FriendsModel;
import com.talkBox.server.model.UserModel;
import org.springframework.stereotype.Service;

import java.util.List;

public interface FriendsService {
    public int addFriend(String userA, String userB);

    public List<UserModel> listFriends(String userAmount);
}
