package com.talkBox.server.vo;

public class AddFriendRequest {
    private String amount;
    private String friendUsername;

    public AddFriendRequest() {
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getFriendUsername() {
        return friendUsername;
    }

    public void setFriendUsername(String friendUsername) {
        this.friendUsername = friendUsername;
    }
}

