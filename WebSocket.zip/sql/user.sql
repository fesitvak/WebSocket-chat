/*
 Navicat Premium Data Transfer

 Source Server         : mysql57
 Source Server Type    : MySQL
 Source Server Version : 50739
 Source Host           : localhost:13306
 Source Schema         : webSocket

 Target Server Type    : MySQL
 Target Server Version : 50739
 File Encoding         : 65001

 Date: 01/07/2023 22:24:05
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sh_user
-- ----------------------------
DROP TABLE IF EXISTS `sh_user`;
CREATE TABLE `sh_user`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `account_number` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '账号（手机号）',
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '邮箱',
  `user_password` varchar(16) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '登录密码',
  `nickname` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '昵称',
  `avatar` varchar(256) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '头像',
  `sign_in_time` datetime NOT NULL COMMENT '注册时间',
  `user_status` tinyint(4) NULL DEFAULT NULL COMMENT '状态（1代表封禁）',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `account_number`(`account_number`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 44 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '用户表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sh_user
-- ----------------------------
INSERT INTO `sh_user` VALUES (36, '15519831391', 'test@361.com', '123456', '东山呀', 'http://localhost:8089/image?imageName=file16881185295121002wallhaven-1pdppw (1).jpg', '2023-05-11 00:53:55', 0);
INSERT INTO `sh_user` VALUES (37, '18713790195', 'test1@361.com', '123456', '程建国', 'http://localhost:8089/image?imageName=file16882191499501002wallhaven-6d5w67.jpg', '2023-04-25 11:20:58', 0);
INSERT INTO `sh_user` VALUES (38, '15263698569', 'test2@361.com', '123456', '张莉莉', 'http://localhost:8089/image?imageName=file16868991923151007wallhaven-6d5w67.jpg', '2023-04-24 07:39:39', 0);
INSERT INTO `sh_user` VALUES (39, '18280424865', 'test3@361.com', '123456', '小米粒', 'http://localhost:8089/image?imageName=file16882200308421003wallhaven-e7kpl8 (1).png', '2023-05-24 08:43:04', 0);
INSERT INTO `sh_user` VALUES (40, '12345678910', 'test4@361.com', '123456', '洪金宝', 'http://localhost:8089/image?imageName=file16850858233271002wallhaven-qzjoo5.png', '2023-05-10 06:23:41', 0);
INSERT INTO `sh_user` VALUES (43, '12312313212', 'test5@361.com', '123456', '张亮', 'http://localhost:8089/image?imageName=file16868991476911006wallhaven-5gz3m1.jpg', '2023-05-01 10:09:40', 0);

SET FOREIGN_KEY_CHECKS = 1;
