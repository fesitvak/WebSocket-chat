/*
 Navicat Premium Data Transfer

 Source Server         : mysql57
 Source Server Type    : MySQL
 Source Server Version : 50739
 Source Host           : localhost:13306
 Source Schema         : talk_box

 Target Server Type    : MySQL
 Target Server Version : 50739
 File Encoding         : 65001

 Date: 01/07/2023 22:23:58
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sh_friends
-- ----------------------------
DROP TABLE IF EXISTS `sh_friends`;
CREATE TABLE `sh_friends`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userA` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `userB` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sh_friends
-- ----------------------------
INSERT INTO `sh_friends` VALUES (1, '15519831391', '18713790195');
INSERT INTO `sh_friends` VALUES (2, '15519831391', '18280424865');
INSERT INTO `sh_friends` VALUES (3, '18713790195', '18280424865');
INSERT INTO `sh_friends` VALUES (4, '15519831391', '12345678910');

SET FOREIGN_KEY_CHECKS = 1;
