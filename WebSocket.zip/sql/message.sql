/*
 Navicat Premium Data Transfer

 Source Server         : mysql57
 Source Server Type    : MySQL
 Source Server Version : 50739
 Source Host           : localhost:13306
 Source Schema         : talk_box

 Target Server Type    : MySQL
 Target Server Version : 50739
 File Encoding         : 65001

 Date: 01/07/2023 22:23:42
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sh_conversion
-- ----------------------------
DROP TABLE IF EXISTS `sh_conversion`;
CREATE TABLE `sh_conversion`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sender_id` bigint(20) NULL DEFAULT NULL,
  `receiver_id` bigint(20) NULL DEFAULT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `time` datetime NULL DEFAULT NULL,
  `status` int(2) NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 40 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sh_conversion
-- ----------------------------
INSERT INTO `sh_conversion` VALUES (35, 36, 39, '你今晚吃什么', '2023-07-01 22:01:30', NULL);
INSERT INTO `sh_conversion` VALUES (36, 39, 36, '不知道哎', '2023-07-01 22:01:38', NULL);
INSERT INTO `sh_conversion` VALUES (37, 39, 36, '你有什么想吃的吗', '2023-07-01 22:01:50', NULL);
INSERT INTO `sh_conversion` VALUES (38, 36, 39, '我想吃麻辣猪蹄，可以吗', '2023-07-01 22:02:03', NULL);
INSERT INTO `sh_conversion` VALUES (39, 39, 36, '狗狗狗', '2023-07-01 22:02:09', NULL);

SET FOREIGN_KEY_CHECKS = 1;
