/*
 Navicat Premium Data Transfer

 Source Server         : mysql57
 Source Server Type    : MySQL
 Source Server Version : 50739
 Source Host           : localhost:13306
 Source Schema         : talk_box

 Target Server Type    : MySQL
 Target Server Version : 50739
 File Encoding         : 65001

 Date: 01/07/2023 22:23:47
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sh_conversion_list
-- ----------------------------
DROP TABLE IF EXISTS `sh_conversion_list`;
CREATE TABLE `sh_conversion_list`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sender_id` bigint(20) NOT NULL,
  `receiver_id` bigint(20) NOT NULL,
  `last_message` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `last_time` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sh_conversion_list
-- ----------------------------
INSERT INTO `sh_conversion_list` VALUES (1, 39, 40, '222', '2023-06-14 14:50:51');
INSERT INTO `sh_conversion_list` VALUES (2, 36, 39, '狗狗狗', '2023-07-01 22:02:09');
INSERT INTO `sh_conversion_list` VALUES (3, 36, 37, 'tets', '2023-06-30 12:23:55');

SET FOREIGN_KEY_CHECKS = 1;
